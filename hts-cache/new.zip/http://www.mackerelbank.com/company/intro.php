
<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>부천현대요양원</title>
	<!-- 부트스트랩 -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<!-- Swiper -->
	<link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css"/>
	<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>	
	<!-- 폰트 -->
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSansNeo.css' rel='stylesheet' type='text/css'>
	<!-- 카카오맵 -->
	<script type="text/javascript" src="//dapi.kakao.com/v2/maps/sdk.js?appkey=11a92710393c1f6ee23c09f2accd78e0"></script>
</head>

<style>
	/* all */
	body{font-family: 'Spoqa Han Sans Neo', 'sans-serif', sans-serif;}
	.h1, .h2, .h3, .h4, .h5, .h6, h1, h2, h3, h4, h5, h6{margin:0}
	a{text-decoration:none}
	button{cursor:pointer}]
	ul,ol,li{list-style:none !important;margin:0;padding:0}
	dl, ol, ul{margin-bottom:0 !important}
	a{cursor:pointer;}
	li::marker{list-style:none;;content:none}
	li::before{list-style:none;content:none}
	p{margin-bottom:0}
	/* 해더 */
	#header{background-color:#fff;position:fixed;width:100%;top:0;z-index:99;box-shadow:rgba(0,0,0,0.1) 1px 1px 14px 4px}
	.headTop{width:100%;background-color:#3ea8c9}
	.headTop .container{overflow:hidden;line-height:40px}
	.headTop p{color:#fff;font-size:11pt}
	.headTop p, .headTop .rightTop{display:inline-block;}
	.headTop .rightTop{float:right;}
	.headTop .rightTop button{background-color:#3ea8c9;border:none;color:#fff;padding:0 15px;line-height:15px;font-size:11pt}
	.headTop .rightTop button:nth-child(2){border-left:1px solid #fff;border-right:1px solid #fff;}
	.headTop .rightTop button:nth-last-child(1){border-right:none !important;}
	#slide-btn{float:right;position:relative;line-height:75px;background-color:#ddd}
	#slide-btn button{height:75px;width:75px;padding:0;border:0;background-color:#3EA8C9;color:#fff}

	#header .inner{height:75px;}
	#header nav{float:right;height:75px;border:none !important}
	#gnb{width:auto !important;}
	#gnb > li > a{line-height:75px;padding:0 20px;font-size:12pt;font-weight:400;color:#000;display:inline-block;height:100%}
	#gnb > li{display:inline-block}
	#gnb > li > ul{top:75px;padding-left:0}
	#header .logo{position:relative;display:inline-block;text-decoration:none;}
	#header .logo h1{margin:13px 0}
	#header .logo img{width:250px;height:50px;vertical-align:top}
	#gnb > li:hover > a, #gnb > li.on > a{color:#3EA8C9;background-color:#fff;box-sizing:border-box;}
	/* #main #content{;padding-top:40px} */
	.head-bak{display:none}
	.userWrap{display:none}


	/* 메인페이지 */
	.swiper{background-color:#ddd;}
	.mySwiper .swiper-slide{height:600px;background-position:right bottom;}
	.lineCon{background-color:#3ea8c9;padding:10px 0;font-size:10pt;color:#fff}
	.lineCon .row{text-align:left;}
	.lineCon .row .line-notice{display:flex;}
	.lineCon .row .line-notice p:nth-child(1){width:100px}
	.lineCon .row .line-notice p{display:inline-block;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}
	.lineCon .row .line-notice div{border-right:0.5px solid #fff;width:25%;text-align:center}

	.mainWrap .mainCon{padding:50px 0}
	.mainWrap .mainCon .title{font-size:25pt;font-weight:800}
	.mainWrap .mainCon .title2{font-size:20pt;font-weight:800}
	.mainWrap .mainCon .title .engTitle{font-size:12pt;margin-bottom:5px;color:#3ea8c9;font-weight:500}
	.mainWrap .mainCon .titleInfo{color:#4b4b4b;margin-top:5px}
	.mainWrap .mainCon .mainConIn{margin-top:30px;}
	.mainWrap .mainCon .mainConIn .col-md-6{padding:0 10px;margin-bottom:20px}
	.mainWrap .mainCon .mainConIn .col-md-6 .conWrap{border:1px solid #ddd;padding:30px;box-sizing:border-box;}
	.mainWrap .mainCon .mainConIn .conWrap .icon{width:150px;line-height:150px;vertical-align:middle;background-color:#f1f2f7;border-radius:100%}
	.mainWrap .mainCon .mainConIn .conWrap .icon img{width:100px}
	.mainWrap .mainCon .mainConIn .conWrap .info{margin-top:15px}
	.mainWrap .mainCon .mainConIn .conWrap .info p{font-size:15pt;font-weight:600}
	.mainWrap .mainCon .mainConIn .conWrap .info span{font-size:11pt;margin-top:5px}

	.middleCon{background-color:#d0eef8;}
	.callJoin i{background-color:#3ea8c9;width:50px;line-height:50px;border-radius:50px;color:#fff;font-size:18pt;margin-bottom:5px;text-align:center;}
	.callJoin a{color:#000;font-weight:800;font-size:25pt}
	.middleCon .callJoin .info{font-size:12pt;padding:0 30px;margin-bottom:15px}
	.middleCon .col-lg-6 .col-sm-6{padding:5px;display:inline-block}
	.middleCon .imgWrap{position:relative;cursor:pointer}
	.middleCon .imgWrap:nth-child(2) img{margin-bottom:0}
	.middleCon .imgWrap img{width:100%;height:120px;object-fit:cover;margin-bottom:10px}
	.middleCon .imgWrap2 img{height:250px;margin-bottom:0}
	.middleCon .imgWrap2 span{line-height:250px !important}
	.middleCon .imgWrap span{position:absolute;width:100%;line-height:120px;background:rgba(0,0,0,0.3);left:0;top:0;text-align:center;color:#fff;font-size:15pt}

	.noticeWrap .col-lg-4{}
	.noticeWrap .col-lg-4:nth-child(2){border-left:0;border-right:0;position:relative;}
	/* .noticeWrap .col-md-4:nth-child(2){border-left:1px solid #ddd;border-right:1px solid #ddd;} */
	.noticeWrap .notice{margin-top:10px;font-size:12pt;line-height:30px;overflow:hidden;cursor:pointer;display:inline-block;width:100%}
	.noticeWrap .notice > div{display:flex}
	.noticeWrap .notice p{text-overflow:ellipsis;overflow:hidden;white-space:nowrap;display:inline-block;width:100%}
	.noticeWrap .notice span{float:right;font-size:10pt;color:gray;text-align:right;width:120px;}
	.noticeWrap .notice .myPhoto{height:150px}
	.noticeWrap .notice .myPhoto .swiper-slide{width:100%;height:150px;background-size:cover !important}
	.noticeWrap .swiper-btn-wrap{position:absolute;right:0;top:0;margin-right:50px;margin-top:30px}
	.noticeWrap .swiper-btn-wrap div{display:inline-block;color:gray;border:1px solid #ddd;font-size:10pt !important;width:30px;height:30px;line-height:30px;text-align:center;right:0}
	.noticeWrap .swiper-button-next:after, .swiper-rtl .swiper-button-prev:after, .swiper-button-prev:after, .swiper-rtl .swiper-button-next:after{font-size:10pt;font-weight:800}
	.noticeWrap .swiper-btn-wrap .swiper-button-next{left:10px !important}
	.noticeWrap .swiper-btn-wrap .swiper-button-prev{left:-25px !important}

	.onlineWrap{background-color:#f2f2f2;background-image:url(/img/inc/bakLogo.png);width:100%;height:auto;background-size:cover;background-position:right bottom;background-repeat:no-repeat}
	.onlineWrap .row .leftWrap{overflow:hidden;}
	.onlineWrap .row .leftWrap > div:nth-child(1){padding-right:15px}
	.onlineWrap .row .leftWrap > div:nth-child(2){padding-left:15px}
	.onlineWrap .row .leftWrap > div{width:50%;float:left;margin-bottom:30px}
	.onlineWrap .row .col-lg-6 > div .title{margin-bottom:10px}
	.onlineWrap .row .col-lg-6 > div span{display:inline-block;width:100%;display:flex;line-height:25px}
	.onlineWrap .row .col-lg-6 > div span font:nth-child(1){width:100px}
	.onlineWrap .onlineForm{width:100% !important;margin-top:10px}
	.onlineWrap .callCenter{width:100% !important}
	.onlineWrap .callJoin a{margin-left:5px;color:#3ea8c9}
	.onlineWrap .callJoin a:hover{color:#3ea8c9}
	
	.chkWrap{margin-bottom:10px}
	.chkWrap input{display:none}
	.chkWrap input + label{display:inline-block;}
	.chkWrap input + label span{display:inline-block !important;width:25px !important;height:25px;border:1px solid #ddd;position:relative;background-color:#fff;vertical-align:middle;margin-right:5px}
	.chkWrap input:checked + label span::after{content:'\2713';width:25px;height:25px;text-align:center;position:absolute;left:0;top:0;background-color:#3ea8c9;color:#fff;font-weight:800}

	.btn01{line-height:45px;padding:0 20px;background-color:#fff;border:0;color:#3ea8c9;font-weight:800;border-radius:3px}
	.btn02{line-height:55px;padding:0 20px;background-color:#3ea8c9;border:0;color:#fff;font-weight:800;border-radius:3px;width:100%}
	.inp{height:45px;background-color:#fff;padding:0 15px;border-radius:3px;width:100%;border:0;margin-bottom:10px}
	textarea.inp{padding:15px;height:100px;resize:none}

	/* 푸터 */
	footer{border-top:1px solid #ddd;display:inline-block;width:100%;margin-top:50px;padding:30px 0}
	footer img{filter: grayscale(100%);opacity:.5;width:200px;}
	footer .termsWrap{margin:10px 0}
	footer .termsWrap a{color:gray;padding:0 10px}
	footer .footerInfo{color:gray;}
	footer .footerInfo font{padding-top:20px;display:inline-block;width:100%;color:#3ea8c9}
	#slide-btn{display:none}
	.close{display:none}

	@media(min-width:992px){
		#header nav{display:inline-block !important}	
	}
	


	@media(max-width:1200px){
		.lineCon{display:none}
		
	}

	@media(max-width:992px){
		#slide-btn{display:inline-block}
		.mySwiper .swiper-slide{height:400px}
		.mainWrap .banText div span{font-size:12pt !important}
		.mainWrap .banText div p{font-size:25pt !important}
		.mainWrap{padding-top:65px !important}
		.mainWrap .mainCon{padding:30px 0}
		.middleCon .row{display:inline-block}
		.middleCon .callJoin{margin-bottom:30px}
		.middleCon .col-lg-6 .col-sm-6{width:100%;display:flex;}
		.middleCon .imgWrap img{margin-bottom:0}
		.middleCon .imgWrap{width:100%}
		.middleCon .imgWrap:nth-child(2){margin-left:10px}
		.middleCon .imgWrap2 img, .middleCon .imgWrap2 span{height:120px !Important;line-height:120px !important}
		.noticeWrap .col-lg-4{margin-bottom:30PX}
		#header #slide-btn{line-height:65px}
		#header .inner{width:100% !important;max-width:992px;padding:0 15px}
		#header .inner, #slide-btn button{height:65px}
		#header nav{position:fixed;right:0;top:0;width:80%;max-width:400px;height:100%;background-color:#fff;z-index:98;display:none}
		#header nav #gnb{padding:0}
		#gnb > li{width:100%;border-bottom:1px solid #ddd}
		#gnb > li > a{width:100%;line-height:45px;font-size:12pt}
		#header .logo img{width:200px !important;height:40px}
		.head-bak{position:fixed;background:rgba(0,0,0,0.3);width:100%;height:100%;left:0;right:0;z-index:50}
		.userWrap{display:inline-block;background-color:#2b2b2b;padding:20px;width:100%;box-sizing:border-box;}
		.userWrap div{display:inline-block;vertical-align:middle}
		.userWrap p{color:#fff;}
		.userWrap button{margin-top:5px;border:1px solid #fff;background-color:#2b2b2b;color:#fff;line-height:25px;width:80px;font-size:10pt;border-radius:0px}
		.userWrap img{width:60px;height:60px;border-radius:100%;background-color:#fff;object-fit:cover;margin-right:10px;vertical-align:middle}

		.mainWrap .mainCon .title{font-size:16pt}
		.onlineWrap .row .col-lg-6 > div span{font-size:10pt;display:inline-block}
		.onlineWrap .row .col-lg-6 > div span font:nth-child(1){display:inline-block;width:80px}
		.mainWrap .mainCon .titleInfo{font-size:10pt}
		.noticeWrap .notice p, .mainWrap .mainCon .mainConIn .conWrap .info span{font-size:10pt}
		.mainWrap .mainCon .mainConIn .conWrap .info p{font-size:14pt;}
		.close{font-size:18pt;color:#fff;position:fixed;margin-left:-24px;margin-top:15px;font-weight:300;display:inline-block}
		.headTop{display:none}
	}





	/* 메뉴해드 */
		/* menuHead */
	a{text-decoration:none;}
	ul, li{list-style:none;margin:0;padding:0}
	.menuHead{width:100%;margin-top:105px}
	.headBak{width:100%;height:300px;background:linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.3)), url(/img/content/menuBak.png) no-repeat bottom center;background-size:cover;text-align:center;}
	.headBak div{padding-top:100px}
	.headBak p{font-size:40px;font-weight:800;color:#fff;}
	.headBak span{font-size:20px;color:#fff;}
	
	.navMenu{width:100%;border-top:1px solid #e5e5e5;border-bottom:1px solid #e5e5e5;box-sizing:border-box;}
	.navMenu .container{width:100%;overflow:hidden;padding:0}
	.navMenu ul li{display:inline-block;float:left;box-sizing:border-box}
	.navMenu ul li a{display:inline-block;width:100%;color:#000;line-height:50px}
	.navMenu .home{border-left:1px solid #e5e5e5;border-right:1px solid #e5e5e5;padding:0 30px;}
	.navMenu .first{border-right:1px solid #e5e5e5;width:200px;;padding:0 15px;}
	.navMenu .depth{border-right:1px solid #e5e5e5;width:250px;padding:0 15px;}
	.navMenu .depth i{margin-top:20px;font-weight:400;float:right;}
	.navMenu .depth .depthIn{position:absolute;width:250px;border:1px solid #e1e1e1;margin-left:-15px;padding:15px;display:none;background-color:#fff;z-index:50}
	.navMenu .depth .depthIn li{display:inline-block;width:100%}
	.navMenu .depth .depthIn li a{line-height:30px}
	.navOn{color:#008eff !important}
	.title3{font-size:16pt;margin-top:15px}
	.title3 b{color:#3ea8c9}
	.introTxt{margin-top:40px;max-width:800px;margin:30px auto;font-size:14pt;text-align:left;padding:0 15px;}
	
	.intro{margin-top:30px}
	.intro img{width:100%}
	.intro img.visible-sm{display:none}
	.subWrap{padding-top:0 !important}
	

	@media(max-width:992px){
		.menuHead{margin-top:65px}
		.navMenu .depth .depthIn{width:150px}
		.navMenu .depth i{margin-top:15px}
		.navMenu ul li a{line-height:40px}
		.introTxt{font-size:12pt}
		.intro img.visible-lg{display:none}
		.intro img.visible-sm{display:inline-block}
		.navMenu .depth,.navMenu .first{width:150px}
		.navMenu ul li{font-size:11pt}
		.headBak p{font-size:30px;}
		.headBak span{font-size:15px;}

		.subWrap .mainCon{padding:30px 15px !important}
	}
</style>

<body>
<header id="header">
	
	<div class="headTop">
		<div class="container">
			<p></p>
			<div class="rightTop">
				<!-- <button type="button" onclick="location.href='/login/process.php?mode=logout'">로그아웃</button>  -->
				<button type="button" onclick="location.href='/login/login.php'">로그인</button>
				<button type="button" onclick="location.href='/login/signup.php'">회원가입</button>
			</div>
		</div>
	</div>
	<div class="head-bak"></div>
     <div class="inner container">
		
        <a href="/" class="logo">
            <h1><img src="/img/inc/h-logo.png" alt="부천현대요양병원"></h1>
        </a>

		<a href="#" id="slide-btn">
			<button>menu</button>
		</a> 

		<nav>
			<i class="fa fa-times close"></i>
			<div class="userWrap">
				<img src="/img/inc/h-logo.png" alt="회원이미지">
				<div class="user">
					<p>로그인이 필요합니다.</p>
					<button type="button">로그인</button>
				</div>

				<!-- <div class="userNo">
					<p><b>김현대</b>님</p>
					<button type="button">로그아웃</button>
				</div> -->
			</div>
			<ul id="gnb">
				<li>
					<a href="/company/intro.php">병원소개</a>
				</li>
				<li>
					<a href="/content/content01.php">진료안내</a>
				</li>
				<li>
					<a href="/content/content02.php">시설안내</a>
				</li>
				<li>
					<a href="/bbs/gallery.php">커뮤니티</a>
				</li>
				<li>
					<a href="/bbs/list.php">상담센터</a>
				</li>
			</ul>
		</nav>


    </div>

    
</header>
<script type="text/javascript" src="http://code.jquery.com/jquery-1.12.4.min.js"></script>
<script>


	 $("#slide-btn").click(function () {
          $("nav,.head-bak").show();
    });

	 $(".close,.head-bak").click(function () {
          $("nav,.head-bak").hide();
    });
</script>


<section class="menuHead">
	<div class="headBak">
		<div class="container">
			<p>병원소개</p>
			<span>부천현대요양병원은 집같이 편안한 곳입니다.</span>
		</div>
	</div>
	<div class="navMenu">
		<div class="container">
			<ul>
				<li class="home">
					<a href=""><i class="fa fa-home"></i></a>
				</li>
				<li class="first">
					<a href="">병원소개</a>
				</li>
				<li class="depth">
					<a href="#">
						인사말
						<i class="fa fa-chevron-down"></i>
					</a>

					<ul class="depthIn">
						<li>
							<a href="" class="navOn">인사말</a>
						</li>
						<li>
							<a href="">의료진소개</a>
						</li>
						<li>
							<a href="">오시는길</a>
						</li>
					</ul>
				</li>
			</ul>
		</div>
	</div>
</section>
<div class="mainWrap subWrap" align="Center">
	<div class="container mainCon">
		<!-- <h4 class="title">
			<p class="engTitle">Intro</p>
			인사말
		</h4> -->

		<!-- <p class="title3">환자와 <b>소통</b>하고 <b>정성</b>으로 돌보는<br> 믿을 수 있는 요양병원이 되겠습니다.</p> -->

		<div class="intro row">
			<div class="col-md-12">
				<img src="/img/content/doctor.png" class="visible-lg">
				<img src="/img/content/doctor-s.png" class="visible-sm">
			</div>

			<div class="introTxt" align="center">
				<p>
					안녕하십니까? 현대요양병원 병원장 김현대입니다.<br>
					저희 병원을 믿고 선택해주신 분들 감사합니다.<br>
					현대요양병원은 보호자들과 환자들이 안심하고 신뢰할 수 있는 <br>편안한 요양원이 되고자 2022년 건물을 확장하게되었습니다.<br><br>
					
					저희 병원을 믿고 선택해주신 분들 감사합니다.
					현대요양병원은 보호자들과 환자들이 안심하고<br> 신뢰할 수 있는 편안한 요양원이 되고자 2022년 건물을 확장하게되었습니다.<br><br>

					안녕하십니까? 현대요양병원 병원장 김현대입니다.<br>
					저희 병원을 믿고 선택해주신 분들 감사합니다.<br>
					현대요양병원은 보호자들과 환자들이 안심하고 신뢰할 수 있는 <br>편안한 요양원이 되고자 2022년 건물을 확장하게되었습니다.<br><br>

					감사합니다.
				</p>
			</div>
		</div>
	</div>
</div>

<script>
	$(".navbar").addClass('navRe');

	$(".depth").on("click",function(){
		$(".depthIn").slideToggle(500);
	});
</script>

<footer align="center">
	<div class="container">
		<img src="/img/inc/h-logo.png" alt="부천현대요양병원">
		<div class="termsWrap">
			<a href="#">개인정보처리방침</a>
			<a href="#">이용약관</a>
			<a href="#">병원소개</a>
		</div>

		<div class="footerInfo">
			<span>경기도 부천시 중동로254번길 24(중동 1151-2) 현대요양병원</span> <br>
			<span>사업자등록번호 123-456-78954</span>
			<span>대표자 김현대</span><br>
			<span>TEL 032-123-4567(원무과)</span>
			<span>TEL 032-123-4567(땡땡과)</span>
			<span>FAX 032-123-4567</span><br>
			<font>COPYRIGHT 2022 HYUNDAI HOSPITAL ALL RIGHTS REERVED</font>
		</div>
	</div>
</footer>